SNIPER DO FUTURO — projeto Android (WebView)

Este projeto empacota a demonstracao 3D em um aplicativo Android de tela cheia.

GERAR APK COM ANDROID STUDIO
1. Instale o Android Studio atualizado.
2. Abra a pasta SniperDoFuturoAndroid no Android Studio.
3. Aguarde a sincronizacao do Gradle e a instalacao do Android SDK Platform 35.
4. Selecione Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de depuracao ficara em app/build/outputs/apk/debug/app-debug.apk.

GERAR APK NA NUVEM (SEM INSTALAR ANDROID STUDIO NO CELULAR)
1. Crie uma conta no GitHub e um repositorio novo.
2. Envie todos os arquivos e pastas deste projeto para o repositorio (mantenha a pasta .github).
3. Abra a aba Actions do repositorio.
4. Escolha "Build Android APK" e toque em "Run workflow" (ou aguarde o build automatico apos enviar para main/master).
5. Quando terminar, abra a execucao concluida e baixe o artefato "SniperDoFuturo-debug-apk".
6. Extraia o ZIP do artefato; dentro estara app-debug.apk. No Android, permita instalar este APK quando solicitado.

REQUISITOS / LIMITACOES
- O projeto requer internet para carregar Three.js de um CDN.
- Este APK e uma demonstracao 3D empacotada em WebView.
- Ainda nao implementa multiplayer, chat de voz, contas, servidor, compras nem validacao real dos 10 primeiros fundadores.
- Este projeto ainda nao foi compilado/testado em um dispositivo Android neste ambiente.
